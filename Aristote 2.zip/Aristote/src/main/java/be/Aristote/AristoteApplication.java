package be.Aristote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AristoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AristoteApplication.class, args);
	}

}
