package be.Aristote.domain.service;

public class CategoryService {
    
}
